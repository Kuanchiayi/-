package tw.ashley.act;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/signupPageServlet.do")
public class signupPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection conn;
	private PrintWriter out;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAction(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAction(request, response);
	}
	public void createConn() throws ClassNotFoundException, SQLException {
		String urlstr = "jdbc:sqlserver://localhost:1433;databaseName=Ashley;user=sa;password=P@ssw0rd";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		conn = DriverManager.getConnection(urlstr);
		boolean status = !conn.isClosed();
		out.write("Connection Open status:" + status + "<br/>");
	}
	public void closeConn() throws SQLException {
		if (conn != null) {
			conn.close();
		}
	}
	private void processAction(HttpServletRequest request, HttpServletResponse response) {
		try{
			String userName = request.getParameter("userName");
			String userPwd = request.getParameter("userPwd");
			
			response.setContentType("text/html;charset=UTF-8");
			out = response.getWriter();
			createConn();
			
			insertUsers(userName, userPwd);
			out.write("���U���\!" + "</br>" + "��^�W�@��");
			
			closeConn();
			out.close();
		}catch(IOException|ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
	}
		public void insertUsers(String user, String pwd) throws SQLException {
			Statement state = conn.createStatement();
			String sqlstr = "Insert Into Custom(username, userpwd) Values('"+ user +"', '"+ pwd +"')";
			state.execute(sqlstr);
			out.write("Insert Success.<br/>");
			state.close();
		}
		
		public void queryDb() throws SQLException {
	        Statement state = conn.createStatement();
	        String sqlstr = "Select * From Custom";
	        ResultSet rs = state.executeQuery(sqlstr);
	        
	        while(rs.next()) {
	        	out.write(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + "<br/>");
	        }
	        
	        rs.close();
	        state.close();
		}

	

}
